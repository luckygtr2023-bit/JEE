# JEE 2028 Tracker — Android APK Project

This project packages the supplied `index(1).html` as a native Android app and adds a native Android home-screen widget.

## Included
- Existing JEE 2028 Tracker HTML UI and localStorage data.
- Native WebView Android app shell.
- Native home-screen widget showing JEE 2028 countdown, today's completed habits, streak, Physics/Chemistry/Maths progress, and rotating motivation text.
- The web app's existing `Capacitor.Plugins.JeeWidget.save(...)` call is bridged to Android, so tracker updates can refresh widget data.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync and install Android SDK Platform 35 / Build Tools if prompted.
3. Select the `app` configuration.
4. Build > Build APK(s).
5. Install the generated APK on your Android tablet.

## Add the widget
After installing, long-press the tablet home screen → Widgets → JEE 2028 Tracker → place it on the home screen.

## Important
The supplied HTML contains the original app logic. The widget is implemented natively because Android home-screen widgets cannot be created from HTML alone.
